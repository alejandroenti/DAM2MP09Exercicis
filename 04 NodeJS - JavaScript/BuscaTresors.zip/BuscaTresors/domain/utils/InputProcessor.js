class InputProcessor {
  static parseInputOption(input) {
    return input.trim().split(" ")
  }
}

module.exports = InputProcessor