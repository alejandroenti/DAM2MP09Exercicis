const Command = require("../../domain/comands/Command")

class CommandAjuda extends Command {

    execute(menuTerminal) {
        this.execute()

        menuTerminal.displayMessage(
            "Llista de comandes:\n" +
            " - ajuda|help - Mostra aquest menú\n" +
            " - carregar partida 'nom_arxiu' - carrega una partida guardada\n" +
            " - guardar partida 'nom_arxiu' - guardar una partida amb el nom indicat\n" + 
            " - activar|desactivar trampes - es mostra un segon taulell amb les caselles destapades\n" +
            "destapar x,y - desmarca la casella indica a x i y, i indica la distància a la que es troba el tresor més proper\n" +
            " - puntuacio - mostra la puntuació actual (tresors aconseguits) i les tirades restants\n\n"
        )
    }
}

module.exports = CommandAjuda