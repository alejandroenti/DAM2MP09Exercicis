const readline = require("readline").promises
const inputProcessor = require("../../domain/utils/InputProcessor")
const CommandAjuda = require("./application/commands/ComamndAjuda")

class MenuTerminal {
    
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })

        this.commands = {
            "ajuda": new CommandAjuda()
        }
    }

    async show() {
        const string = await this.rl.question("Escriu una comanda: ")
        const command = inputProcessor.parseInputOption(string)
        this.displayMessage(command)
    }

    displayMessage(message) {
        console.log(message)
    }

    displayWarningMessage(message) {
        console.warn(message)
    }

    displayErrorMessage(message) {
        console.error(message)
    }
}

module.exports = MenuTerminal